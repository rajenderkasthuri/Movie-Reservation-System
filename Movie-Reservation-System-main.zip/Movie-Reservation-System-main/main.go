package main

import (
	"github.com/raymondoyondi/Movie-Reservation-System/cmd"
)

func main() {
	cmd.Execute()
}
