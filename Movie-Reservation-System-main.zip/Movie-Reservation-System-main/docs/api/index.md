# API Documentations

* [Standard Response Format](response.md)
* [Cinema Management APIs](cinema.md)
* [Movie Management APIs](movie.md)
* [Booking related APIs](booking.md) 
